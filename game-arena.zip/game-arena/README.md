# 🕹️ GAME ARENA

A self-contained arcade dashboard with 5 fully playable games — no server, no dependencies, pure HTML/CSS/JS.

## 🚀 How to Run

Just open `index.html` in any modern browser. No installation needed.

```
open index.html
```

Or drag and drop `index.html` into your browser.

---

## 🎮 Games

| # | Game | Genre | Controls |
|---|------|-------|----------|
| 01 | **Tetris** | Puzzle | Arrow keys, Space (hard drop) |
| 02 | **Snake** | Arcade | Arrow keys or WASD |
| 03 | **Cricket** | Sports | Click to swing at the right moment |
| 04 | **Breakout** | Action | Mouse to move paddle, Click to launch |
| 05 | **Flappy Bird** | Endless | Click or Space to flap |

---

## 📁 File Structure

```
game-arena/
├── index.html          # Main dashboard
├── style.css           # Dashboard styles
├── main.js             # Dashboard logic (game switching, score relay)
├── README.md
└── games/
    ├── tetris.html     # Tetris game
    ├── snake.html      # Snake game
    ├── cricket.html    # Cricket batting game
    ├── breakout.html   # Breakout / Brick breaker
    └── flappy.html     # Flappy Bird clone
```

---

## ✨ Features

- **Single-page dashboard** — select any game, play, return to menu
- **Live score relay** — each game broadcasts scores to the dashboard via `postMessage`
- **Retro CRT aesthetic** — scanlines, neon glows, pixel-perfect styling
- **Fully offline** — works without any internet connection (fonts load from Google Fonts if online)
- **No frameworks** — vanilla HTML5 Canvas + CSS + JS only

---

## 🎨 Design

The arena uses a retro-futuristic CRT aesthetic:
- **Orbitron** display font for headers
- **Share Tech Mono** for UI text  
- Neon color palette with per-game accent colors
- Scanline overlay and grid backgrounds

---

Enjoy the arcade! 🕹️
