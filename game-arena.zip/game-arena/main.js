const gameMap = {
  tetris:   { file: 'games/tetris.html',   title: 'TETRIS' },
  snake:    { file: 'games/snake.html',    title: 'SNAKE' },
  cricket:  { file: 'games/cricket.html',  title: 'CRICKET' },
  breakout: { file: 'games/breakout.html', title: 'BREAKOUT' },
  flappy:   { file: 'games/flappy.html',   title: 'FLAPPY BIRD' },
};

function loadGame(id) {
  const game = gameMap[id];
  if (!game) return;
  document.getElementById('gameFrame').src = game.file;
  document.getElementById('currentGameTitle').textContent = game.title;
  document.getElementById('viewportScore').textContent = '0';
  document.getElementById('dashboard').classList.add('hidden');
  document.getElementById('gameViewport').classList.remove('hidden');
  document.querySelector('.header').style.display = 'none';
  document.querySelector('.footer').style.display = 'none';
}

function backToDashboard() {
  document.getElementById('gameFrame').src = '';
  document.getElementById('gameViewport').classList.add('hidden');
  document.getElementById('dashboard').classList.remove('hidden');
  document.querySelector('.header').style.display = '';
  document.querySelector('.footer').style.display = '';
}

// Listen for score updates from game iframes
window.addEventListener('message', (e) => {
  if (e.data && e.data.type === 'score') {
    document.getElementById('viewportScore').textContent = e.data.value;
  }
});
